import './App.css';
import Races from './component/races.jsx'
function App() {
  return (
    <div className="App">
      <Races />
    </div>
  );
}

export default App;
